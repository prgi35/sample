export class Rating {
    ratingId!:number;

    ratingLabel!:String;
}