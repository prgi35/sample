export class requirement {

    requirementId: number;
    clientName: string;
    projectName: string;
    skills: string;
    experienceRange: string;
    numOfResources: number;

    constructor(requirementId?: number, employeeName?: string, projectName?: string, skills?: string, experienceRange?: string, numOfResources?: number) {
        this.requirementId = requirementId || 0;
        this.clientName = employeeName || '';
        this.projectName = projectName || '';
        this.skills = skills || '';
        this.experienceRange = experienceRange || '';
        this.numOfResources = numOfResources || 0;
    }
}

