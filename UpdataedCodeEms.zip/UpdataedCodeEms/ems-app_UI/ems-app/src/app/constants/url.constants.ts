
export const  UrlConstants = {
     rooturl : 'http://localhost:8080/ems-0.0.1-SNAPSHOT'
    //rooturl : 'http://localhost:8080'
}
