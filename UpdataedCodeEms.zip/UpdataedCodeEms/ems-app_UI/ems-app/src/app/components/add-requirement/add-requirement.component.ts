import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RequirementService } from 'src/app/services/requirement/requirement.service';

@Component({
  selector: 'app-add-requirement',
  templateUrl: './add-requirement.component.html',
  styleUrls: ['./add-requirement.component.css']
})
export class AddRequirementComponent implements OnInit {

  req = new FormGroup({
    requirementId: new FormControl(''),
    clientName: new FormControl(''),
    projectName: new FormControl(''),
    experienceRange: new FormControl(''),
    skills: new FormControl(''),
    numOfResources: new FormControl(''),
  })
  submitted = false;

  constructor(private requirementService: RequirementService, private formBuilder: FormBuilder, private router:Router) { }

  ngOnInit(): void {
    
    this.formBuilder.group({
      clientName: ['', Validators.required],
      projectName: ['', Validators.required],
      experienceRange: ['', Validators.required],
      skills: ['', Validators.required],
      numOfResources: ['', [Validators.required]],
    })
  }

  saveRequirement() {
    this.requirementService.addRequirement(this.req.value).subscribe((data: any) => {
      console.log(this.req.value);
      this.router.navigate(['view-requirement']);
    });
  }

  onSubmit() {
    this.saveRequirement();

  }

}
