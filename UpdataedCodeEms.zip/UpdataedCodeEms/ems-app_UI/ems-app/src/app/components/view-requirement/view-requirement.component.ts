import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { requirement } from 'src/app/model/requirement';
import { RequirementService } from 'src/app/services/requirement/requirement.service';

@Component({
  selector: 'app-view-requirement',
  templateUrl: './view-requirement.component.html',
  styleUrls: ['./view-requirement.component.css']
})
export class ViewRequirementComponent implements OnInit {

  requirement: requirement[];
  constructor(private requirementService: RequirementService, private router: Router) { }

  ngOnInit(): void {

    this.requirementService.getAllRequirements().subscribe((data: any) => {
      //console.log(data);
      this.requirement = data;
      console.log(this.requirement);
    },
      (error) => {
        console.log(error);
      });
  }
}


