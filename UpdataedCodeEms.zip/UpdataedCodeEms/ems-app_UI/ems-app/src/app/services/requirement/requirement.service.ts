import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RequirementService {
  baseURL = "http://localhost:8080/requirement"

  constructor(private http: HttpClient) { }

  //add Employee
  public addRequirement(requirement: any) {
    console.log(requirement);
    return this.http.post(this.baseURL + "/addReq", requirement);

  }

  //get All Requirement Details
  public getAllRequirements() {
    return this.http.get(this.baseURL + "/getAllRequirements");
  }
}

