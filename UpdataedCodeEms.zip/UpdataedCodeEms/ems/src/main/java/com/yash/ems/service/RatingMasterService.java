package com.yash.ems.service;

import java.util.List;

import com.yash.ems.model.RatingMaster;

public interface RatingMasterService {
	
	List<RatingMaster> getRating();

}
