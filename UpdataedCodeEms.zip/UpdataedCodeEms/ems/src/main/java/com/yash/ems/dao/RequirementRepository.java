package com.yash.ems.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ems.model.Requirement;

public interface RequirementRepository extends JpaRepository<Requirement, String> {

}
