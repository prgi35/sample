package com.yash.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ems.dao.RequirementRepository;
import com.yash.ems.model.Requirement;

@Service
public class RequirementService {

	@Autowired
	private RequirementRepository reqRepo;

	// add Requirement Details
	public Requirement saveRequirementDetails(Requirement req) {
		return this.reqRepo.save(req);
	}

	// Get Employee all Details
	public List<Requirement> getAllRequirementDetails() {
		return this.reqRepo.findAll();
	}

}
