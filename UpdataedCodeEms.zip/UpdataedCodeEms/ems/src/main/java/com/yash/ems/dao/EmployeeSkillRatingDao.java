package com.yash.ems.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ems.model.EmployeeSkillRating;

public interface EmployeeSkillRatingDao extends JpaRepository<EmployeeSkillRating,Long> {

}
