package com.yash.ems.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "requirement_details")
public class Requirement {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "requirement_id")
	private int requirementId;

	@Column(name = "client_name")
	private String clientName;

	@Column(name = "project_name")
	private String projectName;

	@Column(name = "skills")
	private String skills;

	@Column(name = "experience_range")
	private String experienceRange;

	@Column(name = "num_Of_Resources")
	private int numOfResources;

	/**
	 * 
	 */
	public Requirement() {
		super();
	}

	/**
	 * @param requirementId
	 * @param clientName
	 * @param projectName
	 * @param skills
	 * @param experienceRange
	 * @param numOfResources
	 */
	public Requirement(int requirementId, String clientName, String projectName, String skills, String experienceRange,
			int numOfResources) {
		super();
		this.requirementId = requirementId;
		this.clientName = clientName;
		this.projectName = projectName;
		this.skills = skills;
		this.experienceRange = experienceRange;
		this.numOfResources = numOfResources;
	}

	/**
	 * @return the requirementId
	 */
	public int getRequirementId() {
		return requirementId;
	}

	/**
	 * @param requirementId the requirementId to set
	 */
	public void setRequirementId(int requirementId) {
		this.requirementId = requirementId;
	}

	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}

	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the skills
	 */
	public String getSkills() {
		return skills;
	}

	/**
	 * @param skills the skills to set
	 */
	public void setSkills(String skills) {
		this.skills = skills;
	}

	/**
	 * @return the experienceRange
	 */
	public String getExperienceRange() {
		return experienceRange;
	}

	/**
	 * @param experienceRange the experienceRange to set
	 */
	public void setExperienceRange(String experienceRange) {
		this.experienceRange = experienceRange;
	}

	/**
	 * @return the numOfResources
	 */
	public int getNumOfResources() {
		return numOfResources;
	}

	/**
	 * @param numOfResources the numOfResources to set
	 */
	public void setNumOfResources(int numOfResources) {
		this.numOfResources = numOfResources;
	}
	
	

}
