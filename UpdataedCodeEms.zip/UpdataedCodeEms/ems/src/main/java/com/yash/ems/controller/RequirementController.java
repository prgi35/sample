package com.yash.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ems.model.Employee;
import com.yash.ems.model.Requirement;
import com.yash.ems.service.RequirementService;

@RestController
@RequestMapping("/requirement")
public class RequirementController {

	@Autowired
	private RequirementService reqService;
	
	
	// add Requirement
		@PostMapping("/addReq")
		public ResponseEntity<Requirement> addRequirement(@RequestBody Requirement req) {
			Requirement saveRequirementDetails = reqService.saveRequirementDetails(req);
			return ResponseEntity.ok(saveRequirementDetails);
		}
		
		// get All Requirements
		@GetMapping("/getAllRequirements")
		public ResponseEntity<List<Requirement>> getAllRequirements() {
			List<Requirement> allRequirementDetails = reqService.getAllRequirementDetails();
			return ResponseEntity.ok(allRequirementDetails);
		}
}
