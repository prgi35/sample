package com.yash.ems.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ems.model.Skills;

public interface SkillsDao extends JpaRepository <Skills ,Long>{

}
