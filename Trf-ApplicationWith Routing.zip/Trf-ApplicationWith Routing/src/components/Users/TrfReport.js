
import React, { useRef,useState  } from "react";
import Card from "../UI/Card/Card";
import Button from "../UI/Button/Button";
import ErrorModel from "../UI/ErrorModel/ErrorModel";
import classes from "./AddUser.module.css";
import "./TrfReport.css";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const TrfReport = (props) => {
    const titleInputRef= useRef();
    const initiatedFromInputRef=useRef ();
    const trainingTypeInputRef=useRef();
    const projectNameInputRef=useRef();
    const resourceTypeInputRef=useRef();
    const skillsInputRef= useRef();
    const durationInputRef=useRef();
    const participantsInputRef=useRef();
    const purposeOfTrainingInputRef=useRef ();
    const startDateInputRef=useRef();
    const endDateRef=useRef();
    const [error , setError] =useState("");
    const navigate = useNavigate();
    const addUserHandler = (event) => {
      event.preventDefault();
      const enteredTitle = titleInputRef.current.value;
      const enteredInitiatedFrom = initiatedFromInputRef.current.value;
      const enteredTrainingType = trainingTypeInputRef.current.value;
      const enteredProject = projectNameInputRef.current.value;
      const enteredResourceType = resourceTypeInputRef.current.value;
      const enteredSkills = skillsInputRef.current.value;
      const enteredDuration = durationInputRef.current.value;
      const enteredParticipants = participantsInputRef.current.value;
      const enteredPurposeOfTraining = participantsInputRef.current.value;
      const enteredStartDate=startDateInputRef.current.value;
      const enteredEndDate =endDateRef.current.value;
      navigate("/trfList");
           if(enteredTitle.trim().length ===true &&
            enteredParticipants.trim().length===0)
            {
              setError({
                  title:"Invalid",
                  message:"Please Enter a valid name and ID (non-empty)",
  
              });
              return;
          }
  
          if(+enteredParticipants < 1){
              setError({
                  title:"Invalid ",
                  message:"Please Enter a valid Participants Should be greater than 0"
              });
  
              return;
  
      }
  
      const newTrf = {
        id: Math.random().toString(),
        title: enteredTitle,
        initiatedFrom: enteredInitiatedFrom,
        trainingType: enteredTrainingType,
        projectName: enteredProject,
        resourceType: enteredResourceType,
        skills: enteredSkills,
        duration: enteredDuration,
        participants: enteredParticipants,
        purposeOfTraining: enteredPurposeOfTraining,
        startDate:new Date(enteredStartDate),
        endDate:new Date(enteredEndDate),
      };
  
      props.onSaveUserData(newTrf);
      // setUserInput({
      //   enteredTitle: "",
      //   enteredInitiatedFrom: "",
      //   enteredTrainingType: "",
      //   enteredProjectName: "",
      //   enteredResourceType: "",
      //   enteredSkills: "",
      //   enteredDuration: "",
      //   enteredParticipants: "",
      //   enteredPurposeOfTraining: "",
      //   enteredStartDate:"",
      //   enteredEndDate: "",
      // });
    
     event.target.reset();
     alert("data saved");
    };
    const errorHandler = (event) => {
      setError(event.target.value);
    };
    return (
      // <div className="container">
      <div>
     
      
          {error && (
            <ErrorModel
              onConfirm={errorHandler}
              title={error.title}
              message={error.message}
            />
          )}
         
          <form className="form" onSubmit={addUserHandler}>
          <div>
            <div className="panel.panel-primary">
              
              <div className="card">
                <div className="panel-heading">
                  <h4 className="panel-title">TRAINING REQUEST FORM </h4>
                </div>
               
                  <div >
                    <div className="text">
                        <br></br>
                      <div className="form-group row">
                        <label className="col-sm-2 ">Training Title:</label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="title"
                            placeholder=""
                            ref={titleInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Initiated From:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="initiatedForm"
                            placeholder=""
                            ref={initiatedFromInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          TrainingType:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="trainingType"
                            placeholder=""
                            ref={trainingTypeInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Project Name:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="projectName"
                            placeholder=""
                            ref={projectNameInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Resource Type:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="resourceType"
                            placeholder=""
                            ref={resourceTypeInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">Skills:</label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="skills"
                            placeholder=""
                            ref={skillsInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Duration:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="duretion"
                            placeholder=""
                            ref={durationInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Participants:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="participants"
                            placeholder=""
                            ref={participantsInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          Purpose of training:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="text"
                            id="puposeOfTraining"
                            placeholder=""
                            ref={purposeOfTrainingInputRef}
                          />
                        </div>
                         <label className="col-sm-2 col-form-label">
                          Start Date:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="date"
                            
                            min="2019-01-01"
                            max="2025-12-31"
                            placeholder=""
                            ref={startDateInputRef}
                          />
                        </div>
                        <label className="col-sm-2 col-form-label">
                          End Date:
                        </label>
                        <div className="col-sm-4">
                          <input
                            type="date"
                            
                            placeholder=""
                            ref={endDateRef}
                          />
                        </div> 
                         </div>
                      <br></br>
                     
                    </div>
                    {/* <Link to='trfList' >
                    <Button type="submit" >Next</Button>
                    </Link> */}
                    <Button type="submit" >Next</Button>
                  </div>
                  <br></br>
                </div>
              </div>
              </div>
          </form>
      </div>
    ); 
  
};

export default TrfReport;