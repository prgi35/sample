import React,{useState} from "react";
// const initialUserList=[
//   {
//    title: "Java",initiatedFrom:"Pooja",trainingType: "Online",projectName: "EMS",resourceType: "On-Bentch",skills: "React",
//    duration: "1Month",participants: "12",purposeOfTraining: "Capabuil",startDate:new Date(),
//    endDate:new Date() }
 
// ]
 const TrfList = (props) => {
//   const [userList , setUserList] = useState(initialUserList);

//   const addUserHandler =(user)=>{
//     setUserList((prevState)=>{
//       return [user ,...prevState];
//     });
//   }
  return (
    <>

      <div className="card">
        <div className="card-header" style={{justifyContent: "space-between", display: "flex"}}>
          <div><h4>Training Request Form</h4></div>
        <div><button>create</button></div>
        </div>
        
        <div className="card-body">
          <table className="table table-hover">
            <tbody>
              <tr>
                <th scope="col">Title</th>
                <th scope="col">Initiated from</th>
                <th scope="col">Training Type</th>
                <th scope="col">Project Name</th>
                <th scope="col">Resource Type</th>
                <th scope="col">Skills </th>
                <th scope="col">Duration</th>
                <th scope="col">participants</th>
                <th scope="col">Purpose of training</th>
                <th scope="col">Start Date</th>
                <th scope="col">EndDate</th>
                <th scope="col">Action</th>
              </tr>

              {props.users.map((user, key) => {
                return (
                  <tr key={key}>
                    <td>{user.title}</td>
                    <td>{user.initiatedFrom}</td>
                    <td>{user.trainingType}</td>
                    <td>{user.projectName}</td>
                    <td>{user.resourceType}</td>
                    <td>{user.skills}</td>
                    <td>{user.duration}</td>
                    <td>{user.participants}</td>
                    <td>{user.purposeOfTraining}</td>
                    <td>{user.startDate.toLocaleDateString()}</td>
                    <td>{user.endDate.toLocaleDateString()}</td>
                    <button type="submit">Upload</button>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};
export default TrfList;
