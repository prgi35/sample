import React from 'react';

import classes from './Navigation.module.css';
import { Link } from 'react-router-dom';

const Navigation = (props) => {
  return (
    <nav className={classes.nav}>
      <ul>
        {props.isLoggedIn && (
          <li>
            <Link to="/Trf">TrfReport</Link>
          </li>
        )}
        {props.isLoggedIn && (
          <li>
            <Link to="/home">Home</Link>
          </li>
        )}
        {props.isLoggedIn && (
          <li>
            
            <button onClick={props.onLogout}>Logout</button>
           
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Navigation;
