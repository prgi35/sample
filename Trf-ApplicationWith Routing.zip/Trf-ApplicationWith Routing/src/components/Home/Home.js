import React from 'react';
import { useState } from "react";
import Card from '../UI/Card/Card';
import classes from './Home.module.css';
import TrfReport from '../Users/TrfReport';
import TrfList from '../Users/TrfList';
const initialUserList=[
  {
   title: "Java",initiatedFrom:"Pooja",trainingType: "Online",projectName: "EMS",resourceType: "On-Bentch",skills: "React",
   duration: "1Month",participants: "12",purposeOfTraining: "Capabuil",startDate:new Date(),
   endDate:new Date() }
 
]

const Home = (props) => {
  const [userList , setUserList] = useState(initialUserList);

  const addUserHandler =(user)=>{
    setUserList((prevState)=>{
      return [user ,...prevState];
    });
  }
  return (
    <Card className={classes.home}>
        <TrfReport onSaveUserData ={addUserHandler}/>
        <TrfList users = {userList} />
    </Card>
  );
};

export default Home;
