import React, { useContext } from "react";


const SignUp = () => {
    const createsignUpContext=useContext('');
    return (
        <div>
            dhddsh
        </div>
    );
};

export default SignUp;