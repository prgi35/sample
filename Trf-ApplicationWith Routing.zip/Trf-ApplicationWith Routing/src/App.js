import React, {  useEffect, useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import {useNavigate} from "react-router-dom";
import Login from './components/Login/Login';
import Home from './components/Home/Home';
import MainHeader from './components/MainHeader/MainHeader';
import TrfList from './components/Users/TrfList';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  //this useEffect will run only once,beacuse there dependency array is blank
  useEffect(()=>{
    const userLoggedInStatus = localStorage.getItem("isLoggedIn");
    if(userLoggedInStatus ==="1"){
      console.log("-------------");
      setIsLoggedIn(true)
    }
  },[]);

  const loginHandler = (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    localStorage.setItem("isLoggedIn","1");
    setIsLoggedIn(true);
  };

  const logoutHandler = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    navigate("/")
  };

  return (
    <React.Fragment>
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      
     <Routes>
        <Route path='/' element= {!isLoggedIn && <Login onLogin={loginHandler} />}/>
        <Route path='/home' element={isLoggedIn && <Home onLogout={logoutHandler} />}/>
        <Route path='/trfList' element={<TrfList />} />
       </Routes>
       
    </React.Fragment>
  ); 
}

export default App;
