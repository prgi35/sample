import React from "react";

import "./UserList.css";
const UserList = (props) => {
  return (
    <div className="App">
      <table>
        <tbody>
          <tr>
            <th>EmployeeId</th>
            <th>Name</th>
            <th>Trainer</th>
            <th>Email</th>
            <th>Experience</th>
            <th>Grade</th>
            <th>CurrentSkill</th>
            <th>Current Allocation</th>
            <th> Project</th>
            <th>current Location</th>
            <th>Upgraded Skill</th>
            <th>Batch</th>
            <th>Mentor</th>
          </tr>
          {props.users.map((user) => {
            return (
              <tr>
                <td>{user.employeeId}</td>
                <td>{user.name}</td>
                <td>{user.trainer}</td>
                <td>{user.email}</td>
                <td>{user.experience}</td>
                <td>{user.grade}</td>
                <td>{user.currentSkill}</td>
                <td>{user.currentAllocation}</td>
                <td>{user.project}</td>
                <td>{user.currentLocation}</td>
                <td>{user.upgradedSkill}</td>
                <td>{user.batch}</td>
                <td>{user.mentor}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default UserList;
