import React,{ useState } from "react";
import Card from "../UI/Card";
import Button from "../UI/Button";
import ErrorModel from "../UI/ErrorModel";
import classes from "./AddUser.module.css"
import "./List.css";
import "./TrfReport.css";


const AddUser = (props) => {
    const [error,setError] = useState("");
    // const[enteredNo,setEnteredNo]=useState("");
    const[enteredEmployeeId,setEnteredEmployeeId]=useState("");
    const[enteredName,setEnteredName]=useState("");
    const[enteredTrainer,setEnteredTrainer]=useState("");
    const[enteredEmail,setEnteredEmail]=useState("");
    const[enteredExperience,setEnteredExperience]=useState("");
    const[enteredGrade,setEnteredGrade]=useState("");
    const[enteredCurrentSkill,setEnteredCurrentSkill]=useState("");
    const[enteredCurrentAllocation,setEnteredCurrentAllocation]=useState("");
    const[enteredProject,setEnteredProject]=useState("");
    const[enteredCurrentLocation,setEnteredCurrentLocation]=useState("");
    const[enteredUpgradedSkill,setEnteredUpgradedSkill]=useState("");
    const[enteredBatch,setEnteredBatch]=useState("");
    const[enteredMentor,setEnteredMentor]=useState("");

    // const numberHandler = (event)=>{
    //     setEnteredNo(event.target.value);

    // };
    const employeeIdHandler = (event)=>{
        setEnteredEmployeeId(event.target.value);

    };
    const nameHandler = (event)=>{
        setEnteredName(event.target.value);

    };
    const trainerHandler = (event)=>{
        setEnteredTrainer(event.target.value);

    };
    const emailHandler = (event)=>{
        setEnteredEmail(event.target.value);

    };
    const experienceHandler = (event)=>{
        setEnteredExperience(event.target.value);

    };
    const gradeHandler = (event)=>{
        setEnteredGrade(event.target.value);

    };
    const currentSkillHandler = (event)=>{
        setEnteredCurrentSkill(event.target.value);

    };
    const currentAlloationHandler = (event)=>{
        setEnteredCurrentAllocation(event.target.value);

    };
    const projectHandler = (event)=>{
        setEnteredProject(event.target.value);

    };
    const currentLocationHandler = (event)=>{
        setEnteredCurrentLocation(event.target.value);

    };
    const upgradedSkillHandler = (event)=>{
        setEnteredUpgradedSkill(event.target.value);

    };
    
    const batchHandler = (event)=>{
        setEnteredBatch(event.target.value);

    };
    const mentorHandler = (event)=>{
        setEnteredMentor(event.target.value);

    };
    
    const addUserHandler = (event) => { 
        event.preventDefault(); 
         if(enteredName.trim().length ===true && enteredEmployeeId.trim().length===0){
            setError({
                title:"Invalid",
                message:"Please Enter a valid name and ID (non-empty)",

            });
            return;
        }

        if(+enteredEmployeeId< 1){
            setError({
                title:"Invalid ",
                message:"Please Enter a valid EmployeeId greater than 0"
            });
        
            return;
     
    }
    
        const newUser = {
            id:Math.random().toString(),
            // number:enteredNo,
            employeeId:enteredEmployeeId,
            name:enteredName,
            trainer:enteredTrainer,
            email:enteredEmail,
            experience:enteredExperience,
            grade:enteredGrade,
            currentSkill:enteredCurrentSkill,
            currentAllocation:enteredCurrentAllocation,
            project:enteredProject,
            currentLocation:enteredCurrentLocation,
            upgradedSkill:enteredUpgradedSkill,
            batch:enteredBatch,
            mentor:enteredMentor

        };
    
        props.onAddUser(newUser);
        // setEnteredNo("");
        setEnteredEmployeeId("");
        setEnteredName("");
        setEnteredTrainer("");
        setEnteredEmail("");
        setEnteredExperience("");
        setEnteredGrade("");
        setEnteredCurrentSkill("");
        setEnteredCurrentAllocation("");
        setEnteredProject("");
        setEnteredCurrentLocation("");
        setEnteredUpgradedSkill("");
        setEnteredBatch("");
        setEnteredMentor("");
    
        // console.log(newUser);

    };

    const errorHandler =(event)=>{
        setError(event.target.value);
    }

     return(
     <div>
         <Card className={classes.input}>
            {error && (
            <ErrorModel onConfirm={errorHandler}
            title={error.title}
            message={error.message}/>
        )}
        
      <form className="form" onSubmit={addUserHandler}>
        <div className="panel.panel-primary">
          <br></br>
          <div className="card">
            <div className="panel-heading">
              <h4 className="panel-title">Participants Detail </h4>
            </div>

            <div className="card-body">
              <div className="form-group row">
                {/* <label className="col-sm-2 ">S.No:</label>
                <div className="col-sm-4">
                  <input
                    type="text"
                    id="number"
                    placeholder=""
                    onChange={numberHandler}
                    value={enteredNo}
                  />
                </div> */}
                <label className="col-sm-2 col-form-label">Employee Id:</label>
                <div className="col-sm-4">
                  <input
                    type="text"
                    id="employeeId"
                    placeholder=""
                     onChange={employeeIdHandler}
                     value={enteredEmployeeId}
                  />
                </div>
                <label className="col-sm-2 col-form-label">Name:</label>
                <div className="col-sm-4">
                  <input
                    type="text"
                    id="name"
                    placeholder=""
                    onChange={nameHandler}
                    value={enteredName}
                  />
                </div>
                <label className="col-sm-2 col-form-label">Trainer:</label>
                <div className="col-sm-4">
                  <input
                    type="text"
                    id="trainer"
                    placeholder=""
                    onChange={trainerHandler}
                    value={enteredTrainer}
                  />
                </div>
                <label className="col-sm-2 col-form-label">Email:</label>
                <div className="col-sm-4">
                  <input
                    type="text"
                    id="email"
                    placeholder=""
                    onChange={emailHandler}
                    value={enteredEmail}
                  />
                </div>
                <label className="col-sm-2 col-form-label">Experience:</label>
                <div className="col-sm-4">
                  <input type="text" id="experience" placeholder="" 
                 onChange={experienceHandler} 
                 value={enteredExperience}/>
                </div>
                <label className="col-sm-2 col-form-label">Grade:</label>
                <div className="col-sm-4">
                  <input type="text" id="grade" placeholder="" 
                  onChange={gradeHandler}
                  value={enteredGrade}/>
                </div>
                <label className="col-sm-2 col-form-label">Current Skill: </label>
                <div className="col-sm-4">
                  <input type="text" id="currentSkill" placeholder="" 
                  onChange={currentSkillHandler}
                  value={enteredCurrentSkill}/>
                </div>
                <label className="col-sm-2 col-form-label">
                  Current Allocation:
                </label>
                <div className="col-sm-4">
                  <input type="text" id="currentAllocation" placeholder="" 
                  onChange={currentAlloationHandler}
                  value={enteredCurrentAllocation} />
                </div>
                <label className="col-sm-2 col-form-label">Project:</label>
                <div className="col-sm-4">
                  <input type="text" id="project" placeholder="" 
                  onChange={projectHandler}
                  value={enteredProject}/>
                </div>
                <label className="col-sm-2 col-form-label">
                  Current location:
                </label>
                <div className="col-sm-4">
                  <input type="text" id="cuurentLocation" placeholder="" 
                  onChange={currentLocationHandler}
                  value={enteredCurrentLocation}/>
                </div>
                <label className="col-sm-2 col-form-label">
                  Upgraded Skill Set:
                </label>
                <div className="col-sm-4">
                  <input type="text" id="upgradedSkill" placeholder=""
                  onChange={upgradedSkillHandler}
                  value={enteredUpgradedSkill}/>
                </div>
                <label className="col-sm-2 col-form-label">Batch:</label>
                <div className="col-sm-4">
                  <input type="text" id="batch" placeholder=""
                 onChange={batchHandler} 
                 value={enteredBatch}/>
                </div>
                <label className="col-sm-2 col-form-label">Mentor:</label>
                <div className="col-sm-4">
                  <input type="text" id="mentor" placeholder="" 
                 onChange={mentorHandler}
                 value={enteredMentor} />
                </div>
                <br></br>
                <div>
                <Button type='submit'>Submit</Button>
                </div>
             
                  {/* <button
                    type="submit"
                    className="btn btn-success"
                   >
                    Submit
                  </button> */}
                
              </div>
            </div>
          </div>
        </div>
      </form>
      </Card>
    </div>
  );
 };
export default AddUser;
