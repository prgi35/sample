import React from "react";
import { useState } from "react";
import Card from "../UI/Card";
import Button from "../UI/Button";
import ErrorModel from "../UI/ErrorModel";
import classes from "./AddUser.module.css";
import "./TrfReport.css";

const TrfReport = (props) => {
  const [error, setError] = useState("");
  const [userInput, setUserInput] = useState({
    enteredTitle: "",
    enteredInitiatedFrom: "",
    enteredTrainingType: "",
    enteredProjectName: "",
    enteredResourceType: "",
    enteredSkills: "",
    enteredDuration: "",
    enteredParticipants: "",
    enteredPurposeOfTraining: "",
    // enteredStartDate: "",
    // enteredEndDate: "",
  });
  const titleChangedHandler = (event) => {
    console.log(event.target.value);
    console.log(userInput);
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredTitle: event.target.value,
      };
    });
  };
  const InitiatedFromChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredInitiatedFrom: event.target.value,
      };
    });
  };
  const TrainingTypeChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredTrainingType: event.target.value,
      };
    });
  };
  const ProjectNameChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredProjectName: event.target.value,
      };
    });
  };
  const ResourceTypeChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredResourceType: event.target.value,
      };
    });
  };
  const SkillsChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredSkills: event.target.value,
      };
    });
  };
  const DurationChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredDuration: event.target.value,
      };
    });
  };
  const ParticipantsChangedHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredParticipants: event.target.value,
      };
    });
  };
  const PurposeOfTrainingChangeHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredPurposeOfTraining: event.target.value,
      };
    });
  };
  const StartDateChangeHandler = (event) => {
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredStartDate: event.target.value,
      };
    });
  };
  const EndDateChangeHandler = (event) => {
    //setEnteredDate(event.target.value);
    setUserInput((prevState) => {
      return {
        ...prevState,
        enteredEndDate: event.target.value,
      };
    });
  };

  const addUserHandler = (event) => {
    event.preventDefault();
         if(userInput.enteredTitle.trim().length ===true && userInput.enteredParticipants.trim().length===0){
            setError({
                title:"Invalid",
                message:"Please Enter a valid name and ID (non-empty)",

            });
            return;
        }

        if(+userInput.enteredParticipants < 1){
            setError({
                title:"Invalid ",
                message:"Please Enter a valid Participants Should be greater than 0"
            });

            return;

    }

    const newTrf = {
      id: Math.random().toString(),
      title: userInput.enteredTitle,
      initiatedFrom: userInput.enteredInitiatedFrom,
      trainingType: userInput.enteredTrainingType,
      projectName: userInput.enteredProjectName,
      resourceType: userInput.enteredResourceType,
      skills: userInput.enteredSkills,
      duration: userInput.enteredDuration,
      participants: userInput.enteredParticipants,
      purposeOfTraining: userInput.enteredPurposeOfTraining,
      startDate:new Date(userInput.enteredStartDate),
      endDate:new Date(userInput.enteredEndDate),
    };

    props.onSaveUserData(newTrf);
    setUserInput({
      enteredTitle: "",
      enteredInitiatedFrom: "",
      enteredTrainingType: "",
      enteredProjectName: "",
      enteredResourceType: "",
      enteredSkills: "",
      enteredDuration: "",
      enteredParticipants: "",
      enteredPurposeOfTraining: "",
      enteredStartDate:"",
      enteredEndDate: "",
    });
    console.log(userInput);
  };
  const errorHandler = (event) => {
    setError(event.target.value);
  };
  return (
    // <div className="container">
    <>
    <div>
      <Card className={classes.input}>
        {error && (
          <ErrorModel
            onConfirm={errorHandler}
            title={error.title}
            message={error.message}
          />
        )}
        <form className="form" onSubmit={addUserHandler}>
          <div className="panel.panel-primary">
            <br></br>
            <div className="card">
              <div className="panel-heading">
                <h4 className="panel-title">TRAINING REQUEST FORM </h4>
              </div>
              <div className="card-header">
                Training Request Initiator Section
                <div className="card-body">
                  <div className="text">
                    <div className="form-group row">
                      <label className="col-sm-2 ">Training Title:</label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="title"
                          placeholder=""
                          onChange={titleChangedHandler}
                          value={userInput.enteredTitle}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Initiated From:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="initiatedForm"
                          placeholder=""
                          onChange={InitiatedFromChangedHandler}
                          value={userInput.enteredInitiatedFrom}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        TrainingType:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="trainingType"
                          placeholder=""
                          onChange={TrainingTypeChangedHandler}
                          value={userInput.enteredTrainingType}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Project Name:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="projectName"
                          placeholder=""
                          onChange={ProjectNameChangedHandler}
                          value={userInput.enteredProjectName}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Resource Type:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="resourceType"
                          placeholder=""
                          onChange={ResourceTypeChangedHandler}
                          value={userInput.enteredResourceType}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">Skills:</label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="skills"
                          placeholder=""
                          onChange={SkillsChangedHandler}
                          value={userInput.enteredSkills}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Duration:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="duretion"
                          placeholder=""
                          onChange={DurationChangedHandler}
                          value={userInput.enteredDuration}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Participants:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="participants"
                          placeholder=""
                          onChange={ParticipantsChangedHandler}
                          value={userInput.enteredParticipants}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        Purpose of training:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="text"
                          id="puposeOfTraining"
                          placeholder=""
                          onChange={PurposeOfTrainingChangeHandler}
                          value={userInput.enteredPurposeOfTraining}
                        />
                      </div>
                       <label className="col-sm-2 col-form-label">
                        Start Date:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="date"
                          
                          min="2019-01-01"
                          max="2025-12-31"
                          placeholder=""
                          onChange={StartDateChangeHandler}
                          value={userInput.enteredStartDate}
                        />
                      </div>
                      <label className="col-sm-2 col-form-label">
                        End Date:
                      </label>
                      <div className="col-sm-4">
                        <input
                          type="date"
                          
                          placeholder=""
                          onChange={EndDateChangeHandler}
                          value={userInput.enteredEndDate}
                        />
                      </div> 
                     
                      
                    
                    </div>
                    <br></br>
                   
                  </div>
                  <Button type="submit">Submit</Button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </Card>
    </div>
    </>
  );
};

export default TrfReport;
