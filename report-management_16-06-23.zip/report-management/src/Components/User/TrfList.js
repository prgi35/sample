import React from "react";
import "./List.css";

const TrfList = (props) => {
  return (
    <div className="App">
      <table>
        <tbody>
          <tr>
            <th>Title</th>
            <th>Initiated from</th>
            <th>Training Type</th>
            <th>Project Name</th>
            <th>Resource Type</th>
            <th>Skills </th>
            <th>Duration</th>
            <th>participants</th>
            <th>Purpose of training</th>
            <th> Start Date</th>
            <th>EndDate</th>
          </tr>
          {props.users.map((user,key) => {
            return (
              <tr key={key}>
                <td>{user.title}</td>
                <td>{user.initiatedFrom}</td>
                <td>{user.trainingType}</td>
                <td>{user.projectName}</td>
                <td>{user.resourceType}</td>
                <td>{user.skills}</td>
                <td>{user.duration}</td>
                <td>{user.participants}</td>
                <td>{user.purposeOfTraining}</td>
                <td>{user.startDate.toLocaleDateString()}</td>
                 <td>{user.endDate.toLocaleDateString()}</td>
                
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
export default TrfList;
