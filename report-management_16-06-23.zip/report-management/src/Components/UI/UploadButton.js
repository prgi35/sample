import React from "react";
import "./UploadButton.css"
const UploadButton =()=>{

    return(
       
        <div className="navbar" class="navbar navbar-default">
         <div container-fluid>
        <button className="upload" button="type">Upload</button>  
        <button className="addButton" button="type">Add Participants</button></div>
        </div>
    )
}

export default UploadButton;