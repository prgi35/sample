import React from "react";
import "./Sidebar.css";

const Sidebar=()=>{

    return(
        <div>
            

    <aside>
      <div >
        <div className="user-panel">
        
        <ul >
          
          <li> 
            <a href="#" data-toggle="collapse" data-target="#dashboard" className="collapsed active">
        <i className="fa fa-user-circle-o"> </i>
         <span className="nav-label"> Admin</span> 
         </a>
         </li>
        <li>
             <a href="#" data-toggle="collapse" data-target="#products" className="collapsed active" > 
        <i className="fa fa-bar-chart-o"></i> 
        <span className="nav-label">Trainer</span>
        </a>
      </li>
      <li> 
        <a  data-toggle="collapse" className="collapsed active" >
        <i className="fa fa-laptop">
            </i> 
            <span className="nav-label" >Feedback</span>
            </a> 
            </li>
      <li> 
        <a href="#" data-toggle="collapse" data-target="#tables" className="collapsed active" >
            <i className="fa fa-table"></i>
             <span className="nav-label">Report</span>
             </a>
    </li>
  </ul>
  </div>
  </div>
  </aside>
  </div>
      
    )
}
export default Sidebar;