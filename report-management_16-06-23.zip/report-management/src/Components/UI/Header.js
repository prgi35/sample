import "./Header.css"
const Header=()=>{
    return(
       <div className="header">
        <h5 className="h3-heading">TRF-REPORT</h5>
       </div>
    )
}
export default Header;