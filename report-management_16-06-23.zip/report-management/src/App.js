import "./App.css";

import Header from "./Components/UI/Header";
import Sidebar from "./Components/UI/Sidebar";
import AddUser from "./Components/User/AddUser";
import TrfReport from "./Components/User/TrfReport";
import UserList from "./Components/User/UserList";
import TrfList from "./Components/User/TrfList";
import { useState } from "react";

// const initialUserList =[
//   {employeeId:"",name:"",trainer:"",email:"",experience:"",grade:"",currenSkill:"",
//   currentAllocation:"",project:"",currentLocation:"",upgradedSkill:"",batch:"",mentor:""}
 
// ]
const initialUserList=[
  {
    title: "",initiatedFrom:"",trainingType: "",projectName: "",resourceType: "",skills: "",
    duration: "",participants: "",purposeOfTraining: "",startDate:new Date(),
   endDate:new Date() }
 
]
function App() {
  // const [trfData,setTrfdata]=useState(trfList);
  // const addUserHandler = (trf)=>{
  //   setTrfdata((prevUserInput)=>{
  //     return[trf , ...prevUserInput];
  //   })
  // }
  const [userList , setUserList] = useState(initialUserList);

  const addUserHandler =(user)=>{
    setUserList((prevState)=>{
      return [user ,...prevState];
    });
  }
  return (
    <div className="App">
      <Header />
      <div className="Body">
        <Sidebar />
        <div>
        {/* <AddUser onAddUser ={addUserHandler}/>
        <UserList users = {userList}/> */}
        <TrfReport onSaveUserData ={addUserHandler}/>
        <TrfList users = {userList} />
        </div>
        {/* <TrfReport />  */}
        {/* <NewTrf onAddUser={addUserHandler}/>
        </div> 
        <UploadButton/>
        <AddEmployee/> */}
     
    </div>
    </div>
  );
}

export default App;
