import { useState } from 'react';
import './App.css';
import UserList from './Components/User/UserList';
// import AddUser from './Components/User/AddUser';
import AddUserCopy from './Components/User/AddUserCopy';

const initialUserList =[
  {id :1 ,userName:"Vishu" , age:45},
  {id:2,userName:"Nikita", age:26},
]
function App() {
  const [userList , setUserList] = useState(initialUserList);

  const addUserHandler =(user)=>{
    setUserList((prevState)=>{
      return [user ,...prevState];
    });
  }
  return (
    <div className="App">
       <h2>User App - Error Management Demo</h2>
       <AddUserCopy onAddUser ={addUserHandler}/>
       <UserList users = {userList}/>
    </div>
  );
}

export default App;
