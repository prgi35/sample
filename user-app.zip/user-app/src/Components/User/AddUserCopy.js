import React, { useRef,useState } from 'react';
import Card from '../UI/Card';
import classes from "./AddUser.module.css"
import Button from "../UI/Button";
import ErrorModel from "../UI/ErrorModel";
;
const AddUserCopy = (props) => {
    
    const nameInputRef = useRef( );
    const ageInputRef = useRef( );
    // const [enteredUserName,setEnteredUserName] = useState("");
    // const [enteredAge,setEnteredAge] = useState("");
    const [error,setError] = useState("");
    const addUserHandler = (event) => { 
        event.preventDefault();
        // console.log("Data saved");
        // Name and age Validtion - non empty
      
        const enteredUserName = nameInputRef.current.value;
        const enteredAge =ageInputRef.current.value;
       
        if(enteredUserName.trim().length ===0 || enteredAge.trim().length===0){
            setError({
                title:"invalid",
                message:"Please Enter a valid name and age (non-empty)",

            });
            return;
        }
        //Age should not be negative

        if(+enteredAge < 1){
            setError({
                title:"Invalid Age",
                message:"Please Enter a valid Age greater than 0"
            });
            return;
            //create user obj
        }
            const newUser = {
                id:Math.random().toString(),
                userName:enteredUserName,
                age:enteredAge,
            };
            props.onAddUser(newUser);
           
            // nameInputRef.setEnteredUserName("")
            // ageInputRef.setEnteredAge("");
            event.target.reset();
           

        };


    const errorHandler =(event)=>{
        setError(event.target.value);

    }
    

    return (
        <div>
            <Card className={classes.input}>
            {error && (
            <ErrorModel onConfirm={errorHandler}
            title={error.title}
            message={error.message}/>
        )}
        
            <form onSubmit={addUserHandler}>
                <label htmlFor='userName'>UserName</label>
                <input id='userName' type="text" ref={nameInputRef} placeholder='userName' />
                <br></br>
                <label htmlFor='age'>Age</label>
                <input id='age' type="text" ref={ageInputRef}/>
                <br></br>
                <Button type='submit'>Add User</Button>
                

            </form>
        </Card>
        </div>
    );

    }
export default AddUserCopy;