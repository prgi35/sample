
import { useState } from 'react';
import './App.css';
import Expenses from './Components/Expenses/Expenses';
import NewExpense from './Components/NewExpenses/NewExpense';

const initialExpenses =[
  { id:1 ,title:"Shopping" , date:new Date(2021 , 6 ,5 ) , amount:2000},
  { id:2 ,title:"School fee" , date:new Date(2020 , 6 ,5 ) , amount:4000},
  { id:3 ,title:"Grocery" , date:new Date(2019 , 6 ,5 ) , amount:4000},
  { id:4 ,title:"Recharge" , date:new Date(2019 , 6 ,5 ) , amount:4000},

];
function App() {
  const [expenses , setExpenses]= useState(initialExpenses);
  const addExpenseHandler =(expense)=>{
    // console.log(expense);
    setExpenses((prevExpenses)=>{
      return [expense , ...prevExpenses];

    })
    
  }

  
  return (
    <div className="App">
      <h1>Expense Management</h1>
      <NewExpense onAddExpense={addExpenseHandler}/>
    <Expenses expenses={expenses}/>
 

    </div>
  );
}


export default App;
