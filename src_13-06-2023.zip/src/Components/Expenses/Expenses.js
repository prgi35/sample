import React from "react";
import ExpenseItem from "./ExpenseItem";
import Card from "../UI/Card";
import "./Expenses.css"
import ExpenseFilter from "./ExpenseFilter";
import { useState } from "react";
import ExpenseList from "./ExpenseList";

const Expenses = (props) => {
  const [filteredYear , setFilterdYear] = useState("2020");
  const{expenses} = props;

  const filterChangeHandler = (selectedYear) =>{
    setFilterdYear(selectedYear);
  }
  const filteredExpenses = expenses.filter((expense)=>{
    return expense.date.getFullYear().toString()===filteredYear;

  });
  // let expensesContent = <p>There is no expense</p>;
  // if (filteredExpenses.length > 0){
  //   expensesContent = filteredExpenses.map((expense)=>{
  //     return<ExpenseItem key={expense.id} expense={expense}/>
  //   });
  // }x 
  return (
    <Card className="expenses">
      <ExpenseFilter 
       selected={filteredYear}
      onChangeFilter={filterChangeHandler}
      />

      <ExpenseList expenses={filteredExpenses}/>
      {/* {filteredExpenses.length === 0 && <p>There is no expenses</p>}
       {filteredExpenses.length>0 && filteredExpenses.map((expense) =>{
        return <ExpenseItem key={expense.id} expense={expense} />
       })} */}
        
      {/* {expenses.map((expense) => {
        return <ExpenseItem key={expense.id} expense={expense} />;
      })} */}
    </Card>
  );
};

export default Expenses;
